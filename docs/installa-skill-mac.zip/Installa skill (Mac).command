#!/bin/bash
echo "Installo le skill /reel-ai e /reel-ai2 per Claude Code..."
echo ""
DEST="$HOME/.claude/skills"
mkdir -p "$DEST"
ZIP="$(mktemp -t reelaiskill).zip"
if curl -fsSL "https://atarantoandrea-png.github.io/video-ai/reel-ai-skill.zip" -o "$ZIP"; then
  tar -xf "$ZIP" -C "$DEST"
  rm -f "$ZIP"
  echo ""
  echo "✅ Fatto! Skill installate in: $DEST"
  echo "   Ora CHIUDI e RIAPRI Claude Code."
  open "$DEST"
else
  echo "Errore di download. Controlla la connessione internet."
fi
echo ""
read -p "Premi Invio per chiudere."
